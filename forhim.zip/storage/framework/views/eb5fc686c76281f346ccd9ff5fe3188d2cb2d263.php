

<?php $__env->startSection('content'); ?>
<div class="container prayer">
    <div class="text-center pt-3 pb-3" >
        <img src="<?php echo e(asset('assets/img/PrayerRequest.png')); ?>" alt="">        
    </div>

    <div class="prayer_text pb-5">
        We consider it an honor that you would trust us to pray for you. Your request will be brought before the Lord Jesus Christ. Our trained staff, Pastor Steve and the ministers take prayer as their purpose in life. Your privacy is of our greatest priority. We will take your prayer request before the Lord and if we receive anything, we will email you what we have for you.
    </div>
    

    <div class="prayer_form pb-5 mt-5">
        <form action="<?php echo e(route('prayer_store')); ?>" method="POST" class="">
            <?php echo csrf_field(); ?>
            <div class="form-group <?php echo e($errors->has('prayer_request') ? ' has-danger' : ''); ?>">
                <label for="prayer_request">Prayer Request</label>
                <span>You are limited to 500 characters. Please be brief.</span>
                <textarea name="prayer_request" id="prayer_request" cols="30" rows="10" class="form-control <?php echo e($errors->has('prayer_request') ? ' is-invalid' : ''); ?>"><?php echo e(old('prayer_request')); ?></textarea>
                <?php $__errorArgs = ['prayer_request'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger mt-2"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="row">
                <div class="col-lg-6">
                    <div class="form-group <?php echo e($errors->has('FirstName') ? ' has-danger' : ''); ?>">
                        <label for="FirstName">First Name</label>
                        <input type="text" name="FirstName" id="FirstName" class="form-control <?php echo e($errors->has('FirstName') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('FirstName')); ?>">
                        <?php $__errorArgs = ['FirstName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger mt-2"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="form-group <?php echo e($errors->has('LastName') ? ' has-danger' : ''); ?>">
                        <label for="LastName">Last Name</label>
                        <input type="text" name="LastName" id="LastName" class="form-control <?php echo e($errors->has('LastName') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('LastName')); ?>">
                        <?php $__errorArgs = ['LastName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger mt-2"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-6">
                    <div class="form-group <?php echo e($errors->has('email') ? ' has-danger' : ''); ?>">
                        <label for="email">Email</label>
                        <input type="text" name="email" id="email" class="form-control <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('email')); ?>" >
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger mt-2"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="col-lg-6 text-center">
                    <input type="submit" value="Submit" class="btn btn-submit">
                </div>
            </div>
           
        </form>
    </div>
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\WEB\2021-02\22\forhim\resources\views/prayer/index.blade.php ENDPATH**/ ?>