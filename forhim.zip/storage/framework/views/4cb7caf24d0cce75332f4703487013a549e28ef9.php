
<?php $__env->startSection('content'); ?>
    <div class="container header">
        <div class="row">
            <div class="col-sm-2 col-3 logo text-center">
                <img src="<?php echo e(asset('assets/img/Logo%20Cross.jpg')); ?>" alt="">
            </div>
            <div class="col-sm-8 col-9 text-center top_img">
                <img src="<?php echo e(asset('assets/img/For%20Him%20Logo%20Clear.png')); ?>" alt="">
            </div>
            <div class="col-sm-2 header_sPart">
                <div>
                    Contact With Us
                </div>
                <div class="header_social">
                    <a href="http://www.facebook.com/For-Him-Ministry-96528235679" target="_blank">
                        <img src="<?php echo e(asset('assets/img/facebook.png')); ?>" alt="">
                    </a>
                    <a href="mailto:CustomerCare@ForHimMinistries.org" target="_blank">
                        <img src="<?php echo e(asset('assets/img/email.png')); ?>" alt="">
                    </a>
                </div>
                <div>
                    Contact Us Today For More Info
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\WEB\2021-02\22\forhim\resources\views/layouts/nav.blade.php ENDPATH**/ ?>